const express = require('express');
const router= express.Router();
const Product = require('../models/product');
const multer = require('multer');

const storage = multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/img/products');
    },
    filename:function(req,file,cb){
        cb(null,Date.now()+'.jpg');
    }
});

const upload = multer({
    storage:storage
});

router.get('/', async (req, res) => {
    try {
        const products = await Product.find();
        res.render('index.ejs', { products: products });
    } catch (err) {
        console.error('Error in GET /:', err);
        res.status(500).send('Database error');
    }
});


router.get('/show/:id',async (req,res)=>{
    try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).send('Not found');
    res.render('show.ejs', { product });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

router.get('/Insert',(req,res)=>{
    res.render('Insert.ejs');
});

router.get('/tableData', async (req, res) => {
    try {
        const products = await Product.find();
        res.render('tableData.ejs', { products: products });
    } catch (err) {
        console.error(err);
        res.status(500).send('Database error');
    }
});


//ส่งข้อมาจากแบบFrom เพื่อบันทึก
router.post('/inserts',upload.single('image'), async (req, res) => {
    try {
        const data = new Product({
            name: req.body.name,
            price: req.body.price,
            size: req.body.size,
            image: req.file.filename,
            description: req.body.description,
            keyfeatures:req.body.keyfeatures
        });

        // await Product.saveProduct(data); // ✅ ใช้ async save
        await data.save(); // ✅ ใช้ save จาก mongoose instance ตรง ๆ
        res.redirect('/');
    } catch (err) {
        console.error(err);
        res.status(500).send('Error saving product');
    }
});

//ลบข้อมูล
router.post('/delete/:id', async (req, res) => {
    try {
        await Product.findByIdAndDelete(req.params.id);
        res.redirect('/');
    } catch (err) {
        console.error(err);
        res.status(500).send('Error deleting product');
    }
});

//แก้ใข
// หน้าแก้ไขข้อมูล
router.get('/edit/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).send('Not found');
    res.render('edit.ejs', { product });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

// บันทึกแก้ไขข้อมูล
router.post('/edit/:id', upload.single('image'), async (req, res) => {
  try {
    const updateData = {
      name: req.body.name,
      price: req.body.price,
      size: req.body.size,
      description: req.body.description,
      keyfeatures:req.body.keyfeatures
    };
    if (req.file) {
      updateData.image = req.file.filename;
    }
    await Product.findByIdAndUpdate(req.params.id, updateData);
    res.redirect('/');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error updating product');
  }
});



module.exports = router;