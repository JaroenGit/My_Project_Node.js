//ใช้งาน mongoose
const mongoose = require('mongoose');
//เชื่อมไปยัง mongoose
const dbUrl = 'mongodb://localhost:27017/productDB';
mongoose.connect(dbUrl).then(() => console.log('MongoDB connected'))
.catch(err => console.error('MongoDB connection error:', err));

//ออกแบบschema
let productSchema = mongoose.Schema({
    name:String,
    price:Number,
    size:String,
    image:String,
    description:String,
    keyfeatures:String
});

//สร้างmodel
let Product = mongoose.model('products',productSchema);

//ส่งออกmodel
module.exports = Product;

//บันทึกข้อมูล
// module.exports.saveProduct = async function (modelInstance) {
//     return await modelInstance.save();
// }